echo Hej Hej 
echo Testar nu att lägga rad bredvid 
echo testar nu vad som händer om jag gör såhär: echo testar om man kan ha två echo på samma rad 


echo två mellanrum från ovan testar 
echo / 

