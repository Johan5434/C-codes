#include <stdio.h>
#include <math.h>
#include <stdlib.h>

/* 
Student name: Johan Eliasson 
tel: 070 454 84 46 
Program: M. Sc Molechular Biotechnology Engineering with master studies in Bioinformatics 
*/

int helper(int **ptr, int i, int j) // helper function for calculating the elements in the triangle 
{
if (i == 0 && j == 0) // I.e if we are looking at the top element, return 1
    {
        return 1; 
    }
else if (j == 0 || j == i) // If we are looking at the left side or right side of triangle, return 1 
    {
        return 1; 
    }
else 
    {
        return ptr[i-1][j-1] + ptr[i-1][j]; // if not the above, return the sum of the previously calculated parents for the new element
    }
}

int main() 

{
int levels; int **ptr; int i, j; 

printf("Ange rader triangeln: "); scanf("%d", &levels); 


ptr = malloc(levels * sizeof(int*)); // allocating memory for the pointer 
for (i = 0; i < levels; i ++) // allocating memory for the pointer which points to "levels" amount of arrays
    {
        ptr[i] = malloc((i+1) * sizeof(int)); // allocating memory for the arrays inside the triangle (integer types)
    }

for (i = 0; i < levels; i++)
    {
    for (j = 0; j < i + 1 ; j ++)
        {
            ptr[i][j] = helper(ptr, i, j); // calculating the elements with helper function 
            printf("%4d", ptr[i][j]); // after calculating, print out the results with 4d space between 
        }
    printf("\n"); // after inner loop (each row), make linebreak 
    }
for (i = 0; i < levels; i ++) // freeing first the inner arrays 
    {
        free(ptr[i]);
    }
free(ptr); // after the inner arrays are freed, free the pointer which points to the arrays with pointers 

return 0;
}
