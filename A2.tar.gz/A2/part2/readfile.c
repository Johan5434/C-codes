#include <stdio.h>
#include <stdlib.h>

/* 
Student name: Johan Eliasson 
tel: 070 454 84 46 
Program: M. Sc Molechular Biotechnology Engineering with master studies in Bioinformatics 
*/


int main() {
FILE *file = fopen("part2/little_bin_file", "rb");
if (file == NULL)
{
    printf("something went wrong when opening trh file "); 
    exit(1); 
}
int number;
fread(&number, sizeof(int), 1, file);
printf("integer value is: %d\n", number);

double double_value;
fread(&double_value, sizeof(double), 1, file);
printf("the double value is: %lf\n", double_value);

char character;
fread(&character, sizeof(char), 1, file);
printf("the char value is: %c\n", character);


float float_value;
fread(&float_value, sizeof(float), 1, file);
printf("float value is: %f\n", float_value);

fclose(file);
return 0;
}

