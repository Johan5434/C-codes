#include <stdio.h>
#include <stdlib.h>
#include <string.h>


/* 
Student name: Johan Eliasson 
tel: 070 454 84 46 
Program: M. Sc Molechular Biotechnology Engineering with master studies in Bioinformatics 
*/


typedef struct linked_element
{
int day; 
float min; 
float max; 
struct linked_element *next; 
} element_t; 

void add_element(element_t **node, int day, float min, float max) 
{
if (*node == NULL || (*node)->day > day) 
{
    element_t *new_node = malloc(sizeof(element_t));
    new_node->day = day;
    new_node->min = min;
    new_node->max = max;
    new_node->next = *node;  
    *node = new_node;        
    return;
}
if ((*node)->day == day) 
{
    (*node)->min = min;
    (*node)->max = max;
    return;
}
add_element(&(*node)->next, day, min, max);
}
void delete_element(element_t **node, int day) {
if (*node == NULL) 
{
    return;
}
if ((*node)->day == day) 
    {
    element_t *temp = *node;
    *node = (*node)->next;  
    free(temp);            
    } 
else 
    {
    delete_element(&(*node)->next, day);  
    }
}

void print_list(element_t *node)
{
if (node == NULL) 
{
    printf("the list is empty\n");
    return;
}
printf("day_____min______max\n");
while (node != NULL) 
{
    printf("%d    %.2f    %.2f\n", node->day, node->min, node->max);
    node = node->next;
}
}
void free_list(element_t *node) {
    while (node != NULL) 
{
    element_t *temp = node;
    node = node->next;
    free(temp);
}
}
int main()
{
element_t *root = NULL;
char command; 
int day; 
float min, max; 

while(1)
{
    printf("enter the command"); 
    scanf(" %c", &command); 
    if (command == 'Q')
    {
        free_list(root);
        break; 
    }
    switch (command)
    {
        case 'A': 
            scanf("%d %f %f", &day, &min, &max);
            if (day < 1 || day > 31) 
            {
            printf("invalid value for the day. It must be a value in range [1, 31]\n");
            continue; 
            }
            add_element(&root, day, min, max);
            break; 

        case 'D': 
            scanf("%d", &day); 
            if (day < 1 || day > 31) 
            {
            printf("invalid value for the day. It must be a value in range [1, 31]\n");
            continue; 
            }
            delete_element(&root, day); 
            break; 
            
        case 'P':
            print_list(root);
            break;
        default: 
        printf("something is wrong with the command\n"); 
    }
}
}
